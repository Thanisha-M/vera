// Drop into the Vercel frontend. Set NEXT_PUBLIC_API / VITE_API to your backend URL.
const API = import.meta?.env?.VITE_API ?? process.env.NEXT_PUBLIC_API;
let token = null;
const hdr = () => (token ? { Authorization: `Bearer ${token}` } : {});
async function j(res) {
  if (!res.ok) throw Object.assign(new Error((await res.json().catch(() => ({}))).detail?.message ?? res.statusText), { status: res.status });
  return res.json();
}
export async function login(email, password) {
  const r = await j(await fetch(`${API}/auth/login`, { method: "POST", body: new URLSearchParams({ username: email, password }) }));
  token = r.access_token; return r;
}
const upload = (path, file, clientId) => {
  const f = new FormData(); f.append("file", file); if (clientId) f.append("client_id", clientId);
  return fetch(`${API}${path}`, { method: "POST", headers: hdr(), body: f }).then(j);
};
export const uploadAudio = (file, clientId) => upload("/upload_audio", file, clientId);
export const uploadVideo = (file, clientId) => upload("/upload_video", file, clientId);
export const analyzeText = (text, clientId) =>
  fetch(`${API}/analyze_text`, { method: "POST", headers: { ...hdr(), "Content-Type": "application/json" }, body: JSON.stringify({ text, client_id: clientId }) }).then(j);
// [{ts, modality, session_id, scores:{stress, confidence, engagement, ...}}] -> feed straight into Recharts/Chart.js
export const getHistory = (clientId) => fetch(`${API}/history${clientId ? `?client_id=${clientId}` : ""}`, { headers: hdr() }).then(j);
export const downloadReport = async (sessionId) => {
  const b = await (await fetch(`${API}/reports/${sessionId}`, { headers: hdr() })).blob();
  window.open(URL.createObjectURL(b));
};
