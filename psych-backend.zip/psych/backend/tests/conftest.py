import base64, os
os.environ.setdefault("DATA_KEY_B64", base64.b64encode(b"k" * 32).decode())
import fakeredis.aioredis as fr
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from qdrant_client import AsyncQdrantClient
from app import deps, security
from app.main import app
from app.services import rag, speech, store, summary


@pytest_asyncio.fixture
async def ctx(monkeypatch):
    r, q = fr.FakeRedis(decode_responses=True), AsyncQdrantClient(":memory:")
    await store.ensure_collections(q)
    app.dependency_overrides[deps.get_redis] = lambda: r
    app.dependency_overrides[deps.get_qdrant] = lambda: q
    app.dependency_overrides[security.current_user] = lambda: security.User(
        id="u1", email="a@b.co", role=security.Role.individual, tenant_id="t1")

    async def fake_explain(*a, **k): return "explained"
    async def fake_narr(*a, **k): return "summary"
    async def fake_match(*a, **k): return None
    monkeypatch.setattr(rag, "explain", fake_explain)
    monkeypatch.setattr(rag, "baseline_match", fake_match)
    monkeypatch.setattr(summary, "narrative", fake_narr)
    monkeypatch.setattr(speech, "analyze_audio", lambda b: ({"stress": .3, "confidence": .6, "anxiety": .2}, [0.1] * 40, {}))
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://t") as c:
        yield c, q
    app.dependency_overrides.clear()
