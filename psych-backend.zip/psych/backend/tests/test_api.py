import io, math, struct, wave
import httpx
import pytest
from qdrant_client import models as m
from app.config import get_settings
from app.services import odoo, speech


def wav_bytes(sec=1.0):
    b = io.BytesIO()
    with wave.open(b, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
        w.writeframes(b"".join(struct.pack("<h", int(8000 * math.sin(i / 20))) for i in range(int(16000 * sec))))
    return b.getvalue()


def up(name, data, mime="audio/wav"):
    return {"file": (name, data, mime)}


async def test_valid_audio(ctx):
    c, q = ctx
    r = await c.post("/upload_audio", files=up("a.wav", wav_bytes()))
    assert r.status_code == 200 and r.json()["scores"]["confidence"] == 0.6
    r2 = await c.post("/upload_audio", files=up("a.wav", wav_bytes()))
    assert r2.json()["cached"] is True                      # Redis cache hit


async def test_empty_file_400(ctx):
    r = await ctx[0].post("/upload_audio", files=up("a.wav", b""))
    assert r.status_code == 400 and r.json()["detail"]["code"] == "empty_file"


async def test_bad_extension_400(ctx):
    r = await ctx[0].post("/upload_audio", files=up("a.txt", wav_bytes()))
    assert r.status_code == 400


async def test_spoofed_mime_400(ctx):
    r = await ctx[0].post("/upload_audio", files=up("a.wav", b"this is plain text, not audio" * 10))
    assert r.status_code == 400 and r.json()["detail"]["code"] == "unsupported_type"


async def test_oversize_413(ctx, monkeypatch):
    monkeypatch.setattr(get_settings(), "max_audio_mb", 0.0001)
    r = await ctx[0].post("/upload_audio", files=up("a.wav", wav_bytes()))
    assert r.status_code == 413


async def test_corrupted_audio_400(ctx, monkeypatch):
    def boom(b): raise ValueError("Could not decode audio")
    monkeypatch.setattr(speech, "analyze_audio", boom)
    r = await ctx[0].post("/upload_audio", files=up("a.wav", wav_bytes()))
    assert r.status_code == 400 and r.json()["detail"]["code"] == "corrupted_media"


async def test_text_validation_422(ctx):
    assert (await ctx[0].post("/analyze_text", json={"text": "short"})).status_code == 422


async def test_individual_cannot_read_other_client(ctx):
    r = await ctx[0].get("/history", params={"client_id": "someone-else"})
    assert r.status_code == 403


async def test_history_and_report(ctx):
    c, _ = ctx
    sid = (await c.post("/upload_audio", files=up("a.wav", wav_bytes()))).json()["session_id"]
    h = (await c.get("/history")).json()
    assert len(h) == 1 and h[0]["session_id"] == sid
    pdf = await c.get(f"/reports/{sid}")
    assert pdf.status_code == 200 and pdf.content.startswith(b"%PDF")


async def test_vector_search_nearest(ctx):
    _, q = ctx
    pts = [m.PointStruct(id=i, vector=v, payload={"kind": "session", "user_hash": "x", "n": i})
           for i, v in enumerate([[1.0] + [0.0] * 39, [0.0, 1.0] + [0.0] * 38, [0.9, 0.1] + [0.0] * 38])]
    await q.upsert("sessions_speech", pts)
    res = await q.query_points("sessions_speech", query=[1.0] + [0.0] * 39, limit=2)
    assert [p.payload["n"] for p in res.points] == [0, 2]


async def test_odoo_sync_handlers():
    calls = []

    def handler(req: httpx.Request):
        p = __import__("json").loads(req.content)["params"]
        calls.append((p["service"], p["method"]))
        if p["method"] == "login": return httpx.Response(200, json={"result": 7})
        if p["args"][4] == "search": return httpx.Response(200, json={"result": []})
        return httpx.Response(200, json={"result": 42})

    c = odoo.OdooClient("http://odoo", "db", "u", "pw", transport=httpx.MockTransport(handler))
    pid = await c.sync_client("Ann", "ann@x.co")
    assert pid == 42
    await c.log_session(pid, "hi")
    assert await c.create_invoice(pid, "Session", 50.0) == 42
    assert ("common", "login") in calls
