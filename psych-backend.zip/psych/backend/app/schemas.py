from pydantic import BaseModel, Field
from .security import Role


class TextIn(BaseModel):
    text: str = Field(min_length=20, max_length=20000)
    client_id: str | None = Field(default=None, max_length=64, pattern=r"^[\w\-.]+$")


class AnalysisResponse(BaseModel):
    session_id: str
    modality: str
    scores: dict[str, float]            # all normalised 0..1
    details: dict = Field(default_factory=dict)
    explanation: str
    summary: str
    baseline_match: str | None = None
    cached: bool = False


class RegisterIn(BaseModel):
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$", max_length=254)
    password: str = Field(min_length=10, max_length=128)
    role: Role = Role.individual
    tenant_id: str = Field(default="public", max_length=64, pattern=r"^[\w\-.]+$")
