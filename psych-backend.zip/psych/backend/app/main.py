import asyncio, contextlib, logging
import redis.asyncio as aioredis
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from qdrant_client import AsyncQdrantClient

from .config import get_settings
from .deps import set_clients
from .routes import analysis, auth, reports
from .services import rag, store

log = logging.getLogger("psych")


async def _retention_loop(q):
    while True:
        try:
            await store.purge_expired(q, get_settings().retention_days)
        except Exception:
            log.exception("retention purge failed")
        await asyncio.sleep(86400)


@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    r = aioredis.from_url(s.redis_url, decode_responses=True, max_connections=50)
    q = AsyncQdrantClient(url=s.qdrant_url)
    set_clients(r, q)
    await store.ensure_collections(q)
    await rag.seed(q)
    task = asyncio.create_task(_retention_loop(q))
    yield
    task.cancel()
    await r.aclose()
    await q.close()


app = FastAPI(title="Psychometric Analysis API", version="1.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=get_settings().cors_origins.split(","),
                   allow_methods=["*"], allow_headers=["*"])
for mod in (auth, analysis, reports):
    app.include_router(mod.router)


@app.get("/healthz")
async def healthz():
    return {"ok": True}
