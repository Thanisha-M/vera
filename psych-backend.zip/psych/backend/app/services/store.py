import asyncio, time
from qdrant_client import AsyncQdrantClient, models as m

COLL = {"speech": "sessions_speech", "vision": "sessions_vision", "text": "sessions_text"}
DIMS = {"sessions_speech": 40, "sessions_vision": 8, "sessions_text": 384, "knowledge": 384}


def _eq(k, v):
    return m.FieldCondition(key=k, match=m.MatchValue(value=v))


async def ensure_collections(q: AsyncQdrantClient):
    for name, dim in DIMS.items():
        if not await q.collection_exists(name):
            await q.create_collection(name, vectors_config=m.VectorParams(size=dim, distance=m.Distance.COSINE))
            for f, t in (("user_hash", m.PayloadSchemaType.KEYWORD), ("kind", m.PayloadSchemaType.KEYWORD),
                         ("ts", m.PayloadSchemaType.FLOAT)):
                await q.create_payload_index(name, f, t)


async def history(q, coll: str, uh: str, limit: int = 200) -> list[dict]:
    pts, _ = await q.scroll(coll, scroll_filter=m.Filter(must=[_eq("user_hash", uh), _eq("kind", "session")]),
                            limit=limit, with_payload=True, with_vectors=False)
    return sorted((p.payload for p in pts), key=lambda p: p["ts"])


async def all_history(q, uh: str) -> list[dict]:
    parts = await asyncio.gather(*(history(q, c, uh) for c in COLL.values()))
    return sorted((p for part in parts for p in part), key=lambda p: p["ts"])


async def erase(q, uh: str):
    for c in COLL.values():
        await q.delete(c, points_selector=m.FilterSelector(filter=m.Filter(must=[_eq("user_hash", uh)])))


async def purge_expired(q, days: int):
    cutoff = time.time() - days * 86400
    f = m.Filter(must=[_eq("kind", "session"), m.FieldCondition(key="ts", range=m.Range(lt=cutoff))])
    for c in COLL.values():
        await q.delete(c, points_selector=m.FilterSelector(filter=f))
