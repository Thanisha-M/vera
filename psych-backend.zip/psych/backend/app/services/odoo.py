import asyncio, base64, logging
import httpx
from ..config import get_settings

log = logging.getLogger(__name__)


class OdooClient:
    def __init__(self, url, db, user, pw, transport=None):
        self.url, self.db, self.user, self.pw, self.uid = url.rstrip("/"), db, user, pw, None
        self.http = httpx.AsyncClient(timeout=20, transport=transport)

    async def _rpc(self, service, method, *args):
        r = await self.http.post(f"{self.url}/jsonrpc", json={"jsonrpc": "2.0", "method": "call", "id": 1,
                                 "params": {"service": service, "method": method, "args": list(args)}})
        r.raise_for_status()
        d = r.json()
        if "error" in d:
            raise RuntimeError(d["error"].get("data", {}).get("message", "Odoo error"))
        return d["result"]

    async def call(self, model, method, args, kwargs=None):
        if self.uid is None:
            self.uid = await self._rpc("common", "login", self.db, self.user, self.pw)
        return await self._rpc("object", "execute_kw", self.db, self.uid, self.pw, model, method, args, kwargs or {})

    async def sync_client(self, name: str, email: str) -> int:
        ids = await self.call("res.partner", "search", [[["email", "=", email]]], {"limit": 1})
        if ids:
            await self.call("res.partner", "write", [ids, {"name": name}])
            return ids[0]
        return await self.call("res.partner", "create", [{"name": name, "email": email}])

    async def log_session(self, partner_id: int, body: str):
        await self.call("res.partner", "message_post", [[partner_id]], {"body": body})

    async def create_invoice(self, partner_id: int, description: str, amount: float) -> int:
        return await self.call("account.move", "create", [{"move_type": "out_invoice", "partner_id": partner_id,
                               "invoice_line_ids": [[0, 0, {"name": description, "quantity": 1, "price_unit": amount}]]}])

    async def attach_report(self, partner_id: int, filename: str, pdf: bytes) -> int:
        return await self.call("ir.attachment", "create", [{"name": filename, "res_model": "res.partner", "res_id": partner_id,
                               "datas": base64.b64encode(pdf).decode(), "mimetype": "application/pdf"}])


async def sync_session(user, state: dict, pdf: bytes | None = None):
    """Background task. Sends a minimal summary only; keep raw scores out of the ERP unless your BAA/DPA allows it."""
    s = get_settings()
    for attempt in range(3):
        try:
            c = OdooClient(s.odoo_url, s.odoo_db, s.odoo_user, s.odoo_password)
            pid = await c.sync_client(user.email, user.email)
            await c.log_session(pid, f"Session {state['session_id']} ({state['modality']}): {state['summary']}")
            if pdf:
                await c.attach_report(pid, f"report-{state['session_id']}.pdf", pdf)
            return
        except Exception as e:
            log.warning("odoo sync attempt %s failed: %s", attempt + 1, e)
            await asyncio.sleep(2 ** attempt)
