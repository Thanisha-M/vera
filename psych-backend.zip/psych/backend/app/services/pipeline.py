import asyncio, json, time, uuid
from fastapi import HTTPException
from ..config import get_settings
from ..schemas import AnalysisResponse
from ..security import encrypt_json
from . import odoo, rag, store, summary


async def compute_cached(redis, modality: str, digest: str, fn):
    key = f"cache:{modality}:{digest}"
    if hit := await redis.get(key):
        d = json.loads(hit)
        return d["scores"], d["vector"], d["details"], True
    try:
        scores, vector, details = await asyncio.to_thread(fn)
    except ValueError as e:
        raise HTTPException(400, {"code": "corrupted_media", "message": str(e)})
    await redis.set(key, json.dumps({"scores": scores, "vector": vector, "details": details}), ex=3600)
    return scores, vector, details, False


async def finalize(*, modality, scores, vector, details, cached, user, uh, redis, qdrant, bg) -> AnalysisResponse:
    s = get_settings()
    sid, ts = str(uuid.uuid4()), time.time()
    from qdrant_client import models as m
    await qdrant.upsert(store.COLL[modality], [m.PointStruct(id=sid, vector=vector, payload={
        "kind": "session", "user_hash": uh, "session_id": sid, "ts": ts, "modality": modality, "scores": scores})])
    explanation = await rag.explain(qdrant, scores, modality, details)
    summ = await summary.narrative(qdrant, uh, modality, scores, sid, explanation)
    match = await rag.baseline_match(qdrant, store.COLL[modality], vector)
    state = {"session_id": sid, "ts": ts, "modality": modality, "scores": scores, "details": details,
             "explanation": explanation, "summary": summ, "baseline_match": match, "uh": uh}
    await redis.set(f"session:{uh}:{sid}", encrypt_json(state), ex=s.retention_days * 86400)
    if s.odoo_enabled:
        bg.add_task(odoo.sync_session, user, state)
    return AnalysisResponse(session_id=sid, modality=modality, scores=scores, details=details, explanation=explanation,
                            summary=summ, baseline_match=match, cached=cached)
