import asyncio, uuid
from qdrant_client import AsyncQdrantClient, models as m
from ..config import get_settings
from . import text as text_svc

KNOWLEDGE = [
    "Elevated vocal stress often shows as higher pitch variability, faster tempo and tense tone; it is a state signal, not a trait, and varies with context such as deadlines or evaluation.",
    "Vocal confidence correlates with steady pace, lower hesitation and calm or positive tone. Low scores can reflect fatigue or unfamiliar topics rather than low self-belief.",
    "Anxiety markers in speech include tremor, faster speech and fearful affect. Screening signals should be followed by a conversation with a qualified professional, never used to diagnose.",
    "Big Five traits: openness, conscientiousness, extraversion, agreeableness, neuroticism. Text-based estimates are noisy and should be treated as conversation starters, not decisions.",
    "Posture and gesture cues: slumped or tilted shoulders, fidgeting and frequent head movement can indicate discomfort; open posture and moderate gesturing usually indicate engagement.",
    "Blink rate rises with stress and cognitive load and falls with intense focus; typical resting rate is roughly 15-20 per minute.",
    "Longitudinal tracking: compare a person with their own earlier sessions rather than with other people; changes of 10-15% matter more than single readings.",
    "Ethical use: psychometric screening must be consensual, explainable and never the sole basis for hiring, grading or clinical decisions.",
]
BASELINES = {
    "calm-conscientious": "I feel calm, organized and confident about handling whatever comes next.",
    "anxious-ruminative": "I am worried and overwhelmed and cannot stop thinking about everything that could go wrong.",
    "outgoing-open": "I love meeting new people and trying new things and my energy is high.",
}


def _id(s):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, s))


async def seed(q: AsyncQdrantClient):
    if (await q.count("knowledge")).count == 0:
        vecs = await asyncio.to_thread(lambda: [text_svc.embed_text(t) for t in KNOWLEDGE])
        await q.upsert("knowledge", [m.PointStruct(id=_id(t), vector=v, payload={"text": t}) for t, v in zip(KNOWLEDGE, vecs)])
    if (await q.count("sessions_text")).count == 0:
        names = list(BASELINES)
        vecs = await asyncio.to_thread(lambda: [text_svc.embed_text(BASELINES[n]) for n in names])
        await q.upsert("sessions_text", [m.PointStruct(id=_id(n), vector=v, payload={"kind": "baseline", "name": n, "user_hash": ""})
                                         for n, v in zip(names, vecs)])


async def baseline_match(q, coll: str, vec: list[float]) -> str | None:
    r = await q.query_points(coll, query=vec, limit=1, with_payload=True,
                             query_filter=m.Filter(must=[m.FieldCondition(key="kind", match=m.MatchValue(value="baseline"))]))
    return r.points[0].payload["name"] if r.points and r.points[0].score > 0.35 else None


async def llm(system: str, prompt: str) -> str | None:
    s = get_settings()
    if not s.anthropic_api_key:
        return None
    try:
        import anthropic
        c = anthropic.AsyncAnthropic(api_key=s.anthropic_api_key)
        r = await c.messages.create(model=s.llm_model, max_tokens=400, system=system,
                                    messages=[{"role": "user", "content": prompt}])
        return r.content[0].text.strip()
    except Exception:
        return None


def _level(v):
    return "high" if v >= 0.66 else "moderate" if v >= 0.33 else "low"


async def explain(q, scores: dict, modality: str, details: dict) -> str:
    facts = ", ".join(f"{k.replace('_', ' ')} {_level(v)} ({v:.0%})" for k, v in scores.items())
    query = f"{modality} analysis: {facts}"
    vec = await asyncio.to_thread(text_svc.embed_text, query)
    hits = (await q.query_points("knowledge", query=vec, limit=3, with_payload=True)).points
    ctx = "\n".join(f"- {h.payload['text']}" for h in hits)
    out = await llm("You explain non-diagnostic psychometric screening scores in plain, kind language. "
                    "Use only the supplied context, never diagnose, max 120 words.",
                    f"Scores ({modality}): {facts}\nDetails: {details}\nContext:\n{ctx}")
    return out or f"Scores ({modality}): {facts}. " + (hits[0].payload["text"] if hits else "")
