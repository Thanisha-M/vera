import tempfile
import numpy as np

L_EYE = [33, 160, 158, 133, 153, 144]
R_EYE = [362, 385, 387, 263, 373, 380]


def _ear(p, idx):
    a = [np.array(p[i]) for i in idx]
    return (np.linalg.norm(a[1] - a[5]) + np.linalg.norm(a[2] - a[4])) / (2 * np.linalg.norm(a[0] - a[3]) + 1e-6)


def _c(x):
    return float(np.clip(x, 0, 1))


def analyze_video(data: bytes):
    """Pose + face-mesh heuristics (posture, gestures, blink rate, head motion). Not diagnostic."""
    import cv2, mediapipe as mp
    with tempfile.NamedTemporaryFile(suffix=".mp4") as f:
        f.write(data); f.flush()
        cap = cv2.VideoCapture(f.name)
        if not cap.isOpened():
            raise ValueError("Could not decode video")
        fps = cap.get(cv2.CAP_PROP_FPS) or 25
        step, i, n = max(1, int(fps // 5)), 0, 0   # ~5 sampled fps, max 300 samples
        tilt, wrist, ear, mouth, nose, prev_w = [], [], [], [], [], None
        with mp.solutions.pose.Pose(static_image_mode=False) as pose, \
             mp.solutions.face_mesh.FaceMesh(refine_landmarks=True) as face:
            while n < 300:
                ok, frame = cap.read()
                if not ok:
                    break
                i += 1
                if i % step:
                    continue
                n += 1
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                pr = pose.process(rgb)
                if pr.pose_landmarks:
                    lm = pr.pose_landmarks.landmark
                    ls, rs, lw, rw = lm[11], lm[12], lm[15], lm[16]
                    width = abs(ls.x - rs.x) + 1e-6
                    tilt.append(abs(ls.y - rs.y) / width)
                    w = np.array([lw.x, lw.y, rw.x, rw.y])
                    if prev_w is not None:
                        wrist.append(float(np.linalg.norm(w - prev_w)))
                    prev_w = w
                    nose.append((lm[0].x, lm[0].y))
                fr = face.process(rgb)
                if fr.multi_face_landmarks:
                    p = [(l.x, l.y) for l in fr.multi_face_landmarks[0].landmark]
                    ear.append((_ear(p, L_EYE) + _ear(p, R_EYE)) / 2)
                    mouth.append(abs(p[13][1] - p[14][1]) / (abs(p[10][1] - p[152][1]) + 1e-6))
        cap.release()
    if n == 0 or not (tilt or ear):
        raise ValueError("No person detected in video")
    dur_min = max(n / 5 / 60, 1e-3)
    blinks = int(np.sum((np.array(ear[1:]) < 0.2) & (np.array(ear[:-1]) >= 0.2))) if len(ear) > 1 else 0
    blink_rate = blinks / dur_min
    mt, ms = (float(np.mean(tilt)), float(np.std(tilt))) if tilt else (0.0, 0.0)
    mw = float(np.mean(wrist)) if wrist else 0.0
    me = float(np.mean(ear)) if ear else 0.0
    mm = float(np.mean(mouth)) if mouth else 0.0
    head = float(np.std(np.array(nose), axis=0).mean()) if len(nose) > 2 else 0.0
    posture, gesture, headm = _c(1 - mt / 0.25), _c(mw / 0.15), _c(head / 0.05)
    blink_dev = _c(abs(blink_rate - 17) / 17)
    scores = {
        "posture": posture, "gesture_activity": gesture, "head_motion": headm,
        "eye_openness": _c(me / 0.4), "blink_rate": _c(blink_rate / 40),
        "stress": _c(0.5 * headm + 0.3 * (1 - posture) + 0.2 * blink_dev),
        "engagement": _c((posture + min(gesture * 1.5, 1) + (1 - blink_dev)) / 3),
    }
    vec = [_c(mt / 0.25), _c(ms / 0.1), gesture, _c(me / 0.4), _c(blink_rate / 40), headm, _c(mm), posture]
    return scores, vec, {"frames_analyzed": n, "blinks": blinks}
