from functools import lru_cache
import numpy as np


@lru_cache
def _sent():
    from transformers import pipeline
    return pipeline("text-classification", model="cardiffnlp/twitter-roberta-base-sentiment-latest", top_k=None)


@lru_cache
def _tone():
    from transformers import pipeline
    return pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base", top_k=None)


@lru_cache
def _ocean():
    from transformers import AutoModelForSequenceClassification, AutoTokenizer
    n = "Minej/bert-base-personality"
    return AutoTokenizer.from_pretrained(n), AutoModelForSequenceClassification.from_pretrained(n)


@lru_cache
def _embedder():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")


def embed_text(t: str) -> list[float]:
    return _embedder().encode(t, normalize_embeddings=True).astype(float).tolist()


def analyze_text(text: str):
    """Sentiment + tone + Big Five (screening-grade text model, not a validated assessment)."""
    import torch
    sent = {r["label"].lower(): r["score"] for r in _sent()(text[:2000])[0]}
    tone = {r["label"].lower(): r["score"] for r in _tone()(text[:2000])[0]}
    tok, model = _ocean()
    inp = tok(text, truncation=True, padding="max_length", max_length=512, return_tensors="pt")
    with torch.no_grad():
        p = 1 / (1 + np.exp(-model(**inp).logits.squeeze().numpy()))
    names = ["extraversion", "neuroticism", "agreeableness", "conscientiousness", "openness"]
    scores = {"sentiment_positivity": float(np.clip((sent.get("positive", 0) - sent.get("negative", 0) + 1) / 2, 0, 1))}
    scores.update({k: float(v) for k, v in zip(names, p)})
    return scores, embed_text(text), {"tone": max(tone, key=tone.get), "tone_scores": {k: round(v, 3) for k, v in tone.items()}}
