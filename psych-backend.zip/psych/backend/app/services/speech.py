import io
from functools import lru_cache
import numpy as np

MODEL = "ehcalabres/wav2vec2-lg-xlsr-en-speech-emotion-recognition"


@lru_cache
def _pipe():
    from transformers import pipeline
    return pipeline("audio-classification", model=MODEL, top_k=None)


def _clip(x):
    return float(np.clip(x, 0, 1))


def analyze_audio(data: bytes):
    """Returns (scores, 40-d MFCC vector, details). Stress/confidence/anxiety are heuristic
    mappings of emotion probabilities, NOT clinical measures."""
    import librosa
    try:
        y, sr = librosa.load(io.BytesIO(data), sr=16000, mono=True, duration=60)
    except Exception as e:
        raise ValueError(f"Could not decode audio: {e}")
    if y.size < 16000 * 0.5:
        raise ValueError("Audio too short (<0.5s)")
    probs = {r["label"].lower(): r["score"] for r in _pipe()({"raw": y, "sampling_rate": sr})}
    g = lambda k: probs.get(k, 0.0)
    scores = {
        "stress": _clip(g("angry") + g("fearful") + 0.5 * g("disgust") + 0.3 * g("sad")),
        "confidence": _clip(g("happy") + g("calm") + 0.5 * g("neutral") - 0.5 * g("fearful")),
        "anxiety": _clip(g("fearful") + 0.5 * g("surprised") + 0.3 * g("sad")),
    }
    mf = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=20)
    vec = np.concatenate([mf.mean(axis=1), mf.std(axis=1)]).astype(float).tolist()
    return scores, vec, {"emotions": {k: round(v, 3) for k, v in probs.items()}}
