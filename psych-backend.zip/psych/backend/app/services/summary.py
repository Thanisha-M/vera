import time
from statistics import mean
from . import rag, store


async def narrative(q, uh: str, modality: str, scores: dict, sid: str, explanation: str) -> str:
    cutoff = time.time() - 14 * 86400
    hist = [h for h in await store.history(q, store.COLL[modality], uh) if h["session_id"] != sid and h["ts"] > cutoff]
    deltas = {}
    for k, v in scores.items():
        vals = [h["scores"][k] for h in hist if k in h["scores"]]
        if vals and mean(vals) > 0.05:
            deltas[k] = round((v - mean(vals)) / mean(vals) * 100)
    notable = [f"{k.replace('_', ' ').capitalize()} {'rose' if d > 0 else 'dropped'} {abs(d)}% versus your 14-day average."
               for k, d in deltas.items() if abs(d) >= 10]
    base = " ".join(notable) or ("First session recorded; later sessions will be compared with this one."
                                 if not hist else "No notable change versus your recent average.")
    out = await rag.llm("Write a short, supportive, actionable summary (max 90 words). Never diagnose. "
                        "Keep every percentage exactly as given.", f"Changes: {base}\nExplanation: {explanation}")
    return out or base
