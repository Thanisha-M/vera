import io, time
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

AUDIENCES = {
    "hr": ("HR Wellbeing & Engagement Report", "Use as one input among many. Not for hiring or disciplinary decisions."),
    "clinical": ("Clinical Screening Summary", "Screening signals only; not a diagnosis. Clinical judgement required."),
    "education": ("Learner Support Report", "Intended to guide supportive conversations, not grading."),
    "self": ("Personal Insights Report", "Self-reflection aid, not a medical or psychological assessment."),
}


def build_pdf(audience: str, state: dict, history: list[dict]) -> bytes:
    title, disclaimer = AUDIENCES[audience]
    st = getSampleStyleSheet()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title=title)
    rows = [["Metric", "Score"]] + [[k.replace("_", " ").title(), f"{v:.0%}"] for k, v in state["scores"].items()]
    t = Table(rows, hAlign="LEFT")
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4f46e5")),
                           ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("GRID", (0, 0), (-1, -1), 0.4, colors.grey)]))
    trend = [["Date", "Modality", "Stress", "Confidence/Engagement"]]
    for h in history[-10:]:
        sc = h["scores"]
        trend.append([time.strftime("%Y-%m-%d", time.gmtime(h["ts"])), h["modality"], f"{sc.get('stress', 0):.0%}",
                      f"{sc.get('confidence', sc.get('engagement', 0)):.0%}"])
    t2 = Table(trend, hAlign="LEFT")
    t2.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, colors.grey)]))
    doc.build([Paragraph(title, st["Title"]), Paragraph(f"Session {state['session_id']} ({state['modality']})", st["Normal"]),
               Spacer(1, 12), t, Spacer(1, 12), Paragraph("Summary", st["Heading2"]), Paragraph(state["summary"], st["Normal"]),
               Paragraph("Explanation", st["Heading2"]), Paragraph(state["explanation"], st["Normal"]),
               Paragraph("Recent trend", st["Heading2"]), t2, Spacer(1, 16),
               Paragraph(f"<i>{disclaimer}</i>", st["Normal"])])
    return buf.getvalue()
