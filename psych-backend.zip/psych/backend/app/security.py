import base64, hashlib, hmac, json, logging, os, time
from enum import Enum

import jwt
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel

from .config import get_settings

log = logging.getLogger(__name__)
oauth2 = OAuth2PasswordBearer(tokenUrl="/auth/login")


class Role(str, Enum):
    counselor = "counselor"
    hr_manager = "hr_manager"
    teacher = "teacher"
    individual = "individual"


class User(BaseModel):
    id: str
    email: str
    role: Role
    tenant_id: str


def err(status: int, code: str, message: str) -> HTTPException:
    return HTTPException(status, {"code": code, "message": message})


# ---- passwords (scrypt) ----
def hash_password(pw: str) -> str:
    salt = os.urandom(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1)
    return base64.b64encode(salt + h).decode()


def verify_password(pw: str, stored: str) -> bool:
    raw = base64.b64decode(stored)
    h = hashlib.scrypt(pw.encode(), salt=raw[:16], n=2**14, r=8, p=1)
    return hmac.compare_digest(h, raw[16:])


# ---- JWT ----
def make_token(u: User) -> str:
    s = get_settings()
    return jwt.encode({**u.model_dump(mode="json"), "sub": u.id,
                       "exp": int(time.time()) + s.jwt_exp_minutes * 60}, s.jwt_secret, "HS256")


async def current_user(token: str = Depends(oauth2)) -> User:
    try:
        d = jwt.decode(token, get_settings().jwt_secret, algorithms=["HS256"])
        return User(id=d["sub"], email=d["email"], role=d["role"], tenant_id=d["tenant_id"])
    except Exception:
        raise err(401, "invalid_token", "Invalid or expired token")


def require_roles(*roles: Role):
    async def dep(u: User = Depends(current_user)) -> User:
        if u.role not in roles:
            raise err(403, "forbidden", "Your role cannot perform this action")
        return u
    return dep


# ---- pseudonymisation + AES-256-GCM at rest ----
def pseudonym(value: str) -> str:
    return hmac.new(get_settings().pseudonym_salt.encode(), value.encode(), hashlib.sha256).hexdigest()


def subject_hash(user: User, client_id: str | None) -> str:
    """Individuals may only act on themselves; staff act on clients inside their tenant."""
    if user.role == Role.individual and client_id not in (None, user.id):
        raise err(403, "forbidden", "Individuals can only access their own data")
    return pseudonym(f"{user.tenant_id}:{client_id or user.id}")


_key: bytes | None = None


def _aes() -> AESGCM:
    global _key
    if _key is None:
        k = get_settings().data_key_b64
        if k:
            _key = base64.b64decode(k)
        else:
            log.warning("DATA_KEY_B64 not set: using an ephemeral key (data unreadable after restart)")
            _key = AESGCM.generate_key(256)
        assert len(_key) == 32, "DATA_KEY_B64 must decode to 32 bytes"
    return AESGCM(_key)


def encrypt_json(obj) -> str:
    nonce = os.urandom(12)
    return base64.b64encode(nonce + _aes().encrypt(nonce, json.dumps(obj).encode(), None)).decode()


def decrypt_json(blob: str):
    raw = base64.b64decode(blob)
    return json.loads(_aes().decrypt(raw[:12], raw[12:], None))
