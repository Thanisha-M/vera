from pathlib import Path
import magic
from fastapi import UploadFile
from .config import get_settings
from .security import err

RULES = {
    "audio": ({".wav", ".mp3", ".m4a"},
              {"audio/x-wav", "audio/wav", "audio/wave", "audio/mpeg", "audio/mp4", "audio/x-m4a", "video/mp4"}),
    "video": ({".mp4", ".webm", ".avi"},
              {"video/mp4", "video/webm", "video/x-msvideo", "video/avi", "video/x-matroska"}),
}


async def read_validated(file: UploadFile, kind: str) -> bytes:
    exts, mimes = RULES[kind]
    s = get_settings()
    if Path(file.filename or "").suffix.lower() not in exts:
        raise err(400, "unsupported_type", f"Allowed extensions: {', '.join(sorted(exts))}")
    limit = int((s.max_audio_mb if kind == "audio" else s.max_video_mb) * 1024 * 1024)
    buf = bytearray()
    while chunk := await file.read(1 << 20):
        buf += chunk
        if len(buf) > limit:
            raise err(413, "too_large", f"Max {limit // (1024 * 1024) or '<1'} MB for {kind}")
    if not buf:
        raise err(400, "empty_file", "Uploaded file is empty")
    if magic.from_buffer(bytes(buf[:4096]), mime=True) not in mimes:
        raise err(400, "unsupported_type", "File content does not match an allowed media type")
    return bytes(buf)
