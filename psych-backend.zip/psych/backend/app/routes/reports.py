from fastapi import APIRouter, Depends, Response
from ..deps import get_qdrant, get_redis, rate_limit
from ..security import Role, User, decrypt_json, err, subject_hash
from ..services import report_pdf, store

router = APIRouter(prefix="/reports", tags=["reports"])
ROLE_AUDIENCE = {Role.hr_manager: "hr", Role.counselor: "clinical", Role.teacher: "education", Role.individual: "self"}


@router.get("/{session_id}")
async def report(session_id: str, client_id: str | None = None, user: User = Depends(rate_limit),
                 redis=Depends(get_redis), qdrant=Depends(get_qdrant)):
    uh = subject_hash(user, client_id)
    blob = await redis.get(f"session:{uh}:{session_id}")
    if not blob:
        raise err(404, "not_found", "Session not found or expired")
    state = decrypt_json(blob)
    pdf = report_pdf.build_pdf(ROLE_AUDIENCE[user.role], state, await store.all_history(qdrant, uh))
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="report-{session_id}.pdf"'})
