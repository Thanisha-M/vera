import hashlib
from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, UploadFile
from ..deps import get_qdrant, get_redis, rate_limit
from ..schemas import AnalysisResponse, TextIn
from ..security import User, err, subject_hash
from ..services import pipeline, speech, store, text as text_svc, vision
from ..validation import read_validated

router = APIRouter(tags=["analysis"])
sha = lambda b: hashlib.sha256(b).hexdigest()


async def _run(modality, digest, fn, user, client_id, redis, qdrant, bg):
    uh = subject_hash(user, client_id)
    scores, vec, details, cached = await pipeline.compute_cached(redis, modality, digest, fn)
    return await pipeline.finalize(modality=modality, scores=scores, vector=vec, details=details, cached=cached,
                                   user=user, uh=uh, redis=redis, qdrant=qdrant, bg=bg)


@router.post("/upload_audio", response_model=AnalysisResponse)
async def upload_audio(bg: BackgroundTasks, file: UploadFile = File(...), client_id: str | None = Form(None),
                       user: User = Depends(rate_limit), redis=Depends(get_redis), qdrant=Depends(get_qdrant)):
    data = await read_validated(file, "audio")
    return await _run("speech", sha(data), lambda: speech.analyze_audio(data), user, client_id, redis, qdrant, bg)


@router.post("/upload_video", response_model=AnalysisResponse)
async def upload_video(bg: BackgroundTasks, file: UploadFile = File(...), client_id: str | None = Form(None),
                       user: User = Depends(rate_limit), redis=Depends(get_redis), qdrant=Depends(get_qdrant)):
    data = await read_validated(file, "video")
    return await _run("vision", sha(data), lambda: vision.analyze_video(data), user, client_id, redis, qdrant, bg)


@router.post("/analyze_text", response_model=AnalysisResponse)
async def analyze_text(body: TextIn, bg: BackgroundTasks, user: User = Depends(rate_limit),
                       redis=Depends(get_redis), qdrant=Depends(get_qdrant)):
    return await _run("text", sha(body.text.encode()), lambda: text_svc.analyze_text(body.text),
                      user, body.client_id, redis, qdrant, bg)


@router.get("/history")
async def history(client_id: str | None = None, user: User = Depends(rate_limit), qdrant=Depends(get_qdrant)):
    """Time series for dashboard charts: [{ts, modality, scores:{stress,confidence,engagement,...}}]"""
    h = await store.all_history(qdrant, subject_hash(user, client_id))
    return [{"ts": p["ts"], "modality": p["modality"], "session_id": p["session_id"], "scores": p["scores"]} for p in h]


@router.delete("/me/data", status_code=204)
async def erase_data(client_id: str | None = None, user: User = Depends(rate_limit),
                     redis=Depends(get_redis), qdrant=Depends(get_qdrant)):
    """GDPR right-to-erasure."""
    uh = subject_hash(user, client_id)
    await store.erase(qdrant, uh)
    async for k in redis.scan_iter(f"session:{uh}:*"):
        await redis.delete(k)
