import hashlib
from fastapi import APIRouter, Depends, Header
from fastapi.security import OAuth2PasswordRequestForm
from ..config import get_settings
from ..deps import get_redis
from ..schemas import RegisterIn
from ..security import (Role, User, decrypt_json, encrypt_json, err, hash_password, make_token, verify_password)

router = APIRouter(prefix="/auth", tags=["auth"])
_k = lambda email: "user:" + hashlib.sha256(email.lower().encode()).hexdigest()


@router.post("/register", status_code=201)
async def register(body: RegisterIn, r=Depends(get_redis), x_admin_token: str | None = Header(default=None)):
    s = get_settings()
    if body.role != Role.individual and not (s.admin_token and x_admin_token == s.admin_token):
        raise err(403, "forbidden", "Staff accounts require an admin token")
    if await r.exists(_k(body.email)):
        raise err(400, "exists", "Account already exists")
    uid = hashlib.sha256(f"{body.tenant_id}:{body.email.lower()}".encode()).hexdigest()[:20]
    await r.set(_k(body.email), encrypt_json({"id": uid, "email": body.email.lower(), "role": body.role.value,
                                              "tenant_id": body.tenant_id, "pw": hash_password(body.password)}))
    return {"id": uid}


@router.post("/login")
async def login(form: OAuth2PasswordRequestForm = Depends(), r=Depends(get_redis)):
    blob = await r.get(_k(form.username))
    d = decrypt_json(blob) if blob else None
    if not d or not verify_password(form.password, d["pw"]):
        raise err(401, "bad_credentials", "Incorrect email or password")
    u = User(id=d["id"], email=d["email"], role=d["role"], tenant_id=d["tenant_id"])
    return {"access_token": make_token(u), "token_type": "bearer", "role": u.role}
