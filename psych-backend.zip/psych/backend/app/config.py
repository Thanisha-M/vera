from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    redis_url: str = "redis://redis:6379/0"
    qdrant_url: str = "http://qdrant:6333"
    jwt_secret: str = "change-me"
    jwt_exp_minutes: int = 60
    admin_token: str = ""            # required to create non-individual accounts
    data_key_b64: str = ""           # base64 of 32 random bytes (AES-256)
    pseudonym_salt: str = "change-me"
    cors_origins: str = "https://psychometric-analysis-demo.vercel.app,http://localhost:3000"
    max_audio_mb: float = 25
    max_video_mb: float = 200
    rate_limit_per_min: int = 30
    retention_days: int = 90
    anthropic_api_key: str = ""
    llm_model: str = "claude-sonnet-5-5"
    odoo_enabled: bool = False
    odoo_url: str = ""
    odoo_db: str = ""
    odoo_user: str = ""
    odoo_password: str = ""


@lru_cache
def get_settings() -> Settings:
    return Settings()
