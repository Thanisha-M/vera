import time
from fastapi import Depends
from .config import get_settings
from .security import User, current_user, err

_redis = None
_qdrant = None


def set_clients(r, q):
    global _redis, _qdrant
    _redis, _qdrant = r, q


def get_redis():
    return _redis


def get_qdrant():
    return _qdrant


async def rate_limit(user: User = Depends(current_user), r=Depends(get_redis)) -> User:
    key = f"rl:{user.id}:{int(time.time() // 60)}"
    n = await r.incr(key)
    if n == 1:
        await r.expire(key, 60)
    if n > get_settings().rate_limit_per_min:
        raise err(429, "rate_limited", "Too many requests, slow down")
    return user
