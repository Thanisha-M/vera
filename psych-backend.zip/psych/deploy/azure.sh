# Azure App Service (container). Redis -> Azure Cache for Redis, Qdrant -> Qdrant Cloud.
az acr build -r $ACR -t psych-api:latest ../backend
az webapp create -g $RG -p $PLAN -n psych-api --deployment-container-image-name $ACR.azurecr.io/psych-api:latest
az webapp config appsettings set -g $RG -n psych-api --settings WEBSITES_PORT=8000 REDIS_URL=$REDIS_URL QDRANT_URL=$QDRANT_URL
az webapp update -g $RG -n psych-api --https-only true --set siteConfig.minTlsVersion=1.2
