# GCP Cloud Run (use Memorystore/Upstash for Redis, Qdrant Cloud for vectors)
gcloud run deploy psych-api --source ../backend --region asia-south1 --memory 4Gi --cpu 2 \
  --timeout 300 --allow-unauthenticated \
  --set-env-vars REDIS_URL=$REDIS_URL,QDRANT_URL=$QDRANT_URL \
  --set-secrets JWT_SECRET=jwt:latest,DATA_KEY_B64=datakey:latest,PSEUDONYM_SALT=salt:latest
