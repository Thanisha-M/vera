# Psychometric Analysis API

    cd backend && cp .env.example .env   # fill secrets
    docker compose up --build            # from repo root; API at https://localhost
    pytest backend                       # 11 tests: uploads, cache, vectors, Odoo, PDF

Endpoints: `POST /auth/register|login`, `/upload_audio`, `/upload_video`, `/analyze_text`,
`GET /history`, `GET /reports/{session_id}` (PDF; audience chosen by role), `DELETE /me/data` (GDPR erasure).

Notes
- First request downloads HF models (~2 GB); bake them into the image for Cloud Run cold starts.
- Staff roles need `X-Admin-Token`; individuals self-register. Staff only see clients in their own tenant.
- Qdrant stores pseudonymised IDs + numeric scores only; raw text/audio is never stored. Session state in Redis is AES-256-GCM encrypted and expires after RETENTION_DAYS.
- Stress/confidence/anxiety are heuristic mappings of emotion models: screening signals, not diagnoses.
- Before real HIPAA/GDPR use: move users to Postgres, add audit logging, sign BAAs/DPAs, and get a compliance review.
